#pragma once

class GameState;

class InputHandler {
 public:
  void ProcessInput(GameState& gameState);
};
